<!doctype html><html lang="en" id="htmlRoot"><head><script src="/_app.config.js?v=2.8.0-1707128923803"></script><meta charset="UTF-8"/><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/><meta name="renderer" content="webkit"/><meta name="google-site-verification" content="google-site-verification=J78w__7UhuKmPPP8Ip4SicL3qQk8zQbkMBYUThBbHYQ"/><meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=0"/><link rel="preconnect" href="https://fonts.googleapis.com"/><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/><link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet"/><title>AppleSwap</title><link rel="icon" href="/favicon.ico"/><title>AppleSwap</title><link rel="canonical" href="https://appleswap.ai/"/><meta name="description" content="Trade cryptocurrencies effortlessly with AppleSwap. Buy, sell, and exchange digital assets securely. Join now for endless possibilities in crypto!"/><meta name="keywords" content="appleswap, cryptocurrency exchange, digital assets, buy crypto, sell crypto, secure trading, crypto marketplace, crypto trading platform, decentralized finance, blockchain technology, token exchange"/><meta property="og:title" content="AppleSwap - Home"/><meta property="og:type" content="website"/><meta property="og:url" content="https://appleswap.ai/"/><meta property="og:image" content="https://appleswap.ai//images/logo.png"/><script src="script.js"></script><script type="module" crossorigin src="/assets/index.d1971cae.js"></script><link rel="stylesheet" href="/assets/index.9df13cc8.css"><link disabled="disabled" id="__VITE_PLUGIN_THEME-ANTD_DARK_THEME_LINK__" rel="alternate stylesheet" href="/assets/app-antd-dark-theme-style.e3b0c442.css"></head><script type="application/ld+json">{
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://appleswap.ai/"
        }
      ]
    }</script><script async src="https://www.googletagmanager.com/gtag/js?id=G-8SFLW1WDH1"></script><script>window.dataLayer = window.dataLayer || [];
    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'G-8SFLW1WDH1');</script><body><script>(() => {
        var htmlRoot = document.getElementById('htmlRoot');
        var theme = window.localStorage.getItem('__APP__DARK__MODE__');
        if (htmlRoot && theme) {
          htmlRoot.setAttribute('data-theme', theme);
          theme = htmlRoot = null;
        }
      })();</script><div id="app"><style>html[data-theme=dark] .app-loading{background-color:#2c344a}html[data-theme=dark] .app-loading .app-loading-title{color:rgb(255 255 255 / 85%)}.app-loading{display:flex;width:100%;height:100%;justify-content:center;align-items:center;flex-direction:column;background-color:#2c344a}.app-loading .app-loading-wrap{position:absolute;top:50%;left:50%;display:flex;transform:translate3d(-50%,-50%,0);justify-content:center;align-items:center;flex-direction:column}.app-loading .app-loading-title{display:flex;margin-top:30px;font-size:30px;color:rgb(0 0 0 / 85%);justify-content:center;align-items:center}.app-loading .app-loading-logo{display:block;width:90px;margin:0 auto;margin-bottom:20px}.lds-ellipsis{display:inline-block;position:relative;width:80px;height:80px}.lds-ellipsis div{position:absolute;top:33px;width:13px;height:13px;border-radius:50%;background:#ffb400;animation-timing-function:cubic-bezier(0,1,1,0)}.lds-ellipsis div:first-child{left:8px;animation:lds-ellipsis1 .6s infinite}.lds-ellipsis div:nth-child(2){left:8px;animation:lds-ellipsis2 .6s infinite}.lds-ellipsis div:nth-child(3){left:32px;animation:lds-ellipsis2 .6s infinite}.lds-ellipsis div:nth-child(4){left:56px;animation:lds-ellipsis3 .6s infinite}@keyframes lds-ellipsis1{0%{transform:scale(0)}100%{transform:scale(1)}}@keyframes lds-ellipsis3{0%{transform:scale(1)}100%{transform:scale(0)}}@keyframes lds-ellipsis2{0%{transform:translate(0,0)}100%{transform:translate(24px,0)}}</style><div class="app-loading"><div class="app-loading-wrap"><img style="width:300px" src="/resource/img/logo.svg" class="app-loading-logo" alt="Logo"/><div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div></div></div></div></body></html>